# Partner Logos

Place partner logo files in this directory. Expected logo files:

- bigcommerce.webp
- clover.webp
- clovernet.svg
- freshbooks.webp
- hubspot.webp
- keap.webp
- lightspeed.webp
- magento.webp
- mastercard.webp
- memberpress.svg
- ncr.webp
- quickbooks.webp
- salesforce.webp
- squarespace.webp
- vend.webp
- visa.webp
- wix.webp
- woocommerce.webp
- zoho_crm.webp

These logos will be displayed in the scrolling logo banner on the homepage.
